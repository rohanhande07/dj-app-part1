import React,{Component} from 'react';
import { Text, View, Button} from 'react-native';

class SoundButton1 extends Component{
  render(){
    return(
    <Button color={this.props.color} title="Sound1"onPress={this.displayAlert}/>
    )
    
  }
  displayAlert=function(){
  alert("You Chose Button1")
  }
}
class SoundButton2 extends Component{
  render(){
    return(
    <Button color={this.props.color} title="Sound2"onPress={this.displayAlert}/>
    )
    
  }
  displayAlert=function(){
  alert("You Chose Button2")
  }
}
class SoundButton3 extends Component{
  render(){
    return(
    <Button color={this.props.color} title="Sound3"onPress={this.displayAlert}/>
    )
    
  }
  displayAlert=function(){
  alert("You Chose Button3")
  }
}
class SoundButton4 extends Component{
  render(){
    return(
    <Button color={this.props.color} title="Sound4"onPress={this.displayAlert}/>
    )
    
  }
  displayAlert=function(){
  alert("You Chose Button4")
  }
}
class SoundButton5 extends Component{
  render(){
    return(
    <Button color={this.props.color} title="Sound5"onPress={this.displayAlert}/>
    )
    
  }
  displayAlert=function(){
  alert("You Chose Button5")
  }
}

export default class App extends Component {
  render() {
    return(
      <View style={{marginTop:100}}>
      <SoundButton1 color="red"/>
      <SoundButton2 color="yellow"/>
      <SoundButton3 color="green"/>
      <SoundButton4 color="blue"/>
      <SoundButton5 color="orange"/>
      </View>
    );
  }
}

